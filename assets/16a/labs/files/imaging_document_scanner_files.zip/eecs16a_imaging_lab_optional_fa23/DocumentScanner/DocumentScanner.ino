#define LED A1

unsigned long firstSensor = 0;    // first analog sensor
unsigned int numAvgs = 50;
int handshake = 0;
int len = 8*8;

void setup()
{
  // initialize the digital pin as an output.
  pinMode(LED, OUTPUT);
  
  // start serial port at 115200 bps:
  Serial.begin(115200);
  while (!Serial) {
    ; // wait for serial port to connect. Needed for Leonardo only
  }
}

void loop() {
  // if we get a valid byte, read analog ins:
  if (Serial.available() > 0) {
    handshake = Serial.read();
    if (handshake == 57)  // Ascii code for numerical 9
      Serial.flush();
    else if (handshake == 54) { // Ascii code for 6 so serial monitor works
      for (int i = 0; i < len; i++) {
        firstSensor = 0;
        digitalWrite(LED, HIGH);
        delay(475);
        for (int count = 0; count < numAvgs; count++) {  
          firstSensor += analogRead(A0);
          delay(1);
        }
        Serial.print(firstSensor / numAvgs, DEC);
        if (i != len-1)
          Serial.println(",");
        delay(475);
        digitalWrite(LED, LOW);
        delay(1000);
      }
    }
  }
}
