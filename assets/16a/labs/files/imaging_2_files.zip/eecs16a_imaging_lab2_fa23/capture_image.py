#!/usr/bin/python
import sys
import argparse
import numpy as np
import matplotlib.pyplot as plt
import time
import glob
import signal
import serial
import serial.tools.list_ports
import socket

from PyQt5 import QtGui, QtCore, QtWidgets, QtNetwork


global SCAN_DELAY
# Total time to delay for at start of scan in milliseconds
SCAN_DELAY = 1000

# Projector dimensions are 1280 x 720
DEFAULT_DISP_WIDTH = 1280
DEFAULT_DISP_HEIGHT = 720

BAUD_RATE = 115200


def input_int(prompt):
  while True:
    print(prompt)
    raw_val = input()
    try:
      return int(raw_val)
    except ValueError:
      print('The value entered was not an integer. Please try again.')
      continue


class Mask(QtWidgets.QWidget):
  def __init__(self, ser, fps, img_width, img_height, infile, outfile, num_captures, brightness_pct, sleep_time_ms):
    super(Mask, self).__init__()

    self.setAutoFillBackground(True)
    p = self.palette()
    p.setColor(self.backgroundRole(), QtCore.Qt.black)
    self.setPalette(p)

    # Set up shortcuts to close the program
    QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+Q"), self, self.close)
    QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+W"), self, self.close)
    QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+C"), self, self.close)
    QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+D"), self, self.close)
    QtWidgets.QShortcut(QtGui.QKeySequence("Esc"), self, self.close)

    self.ser = ser                  # Serial port
    self.scan_rate = fps            # Scan rate in fps (each pixel movement = 1 frame)
    self.img_width = img_width        # Matrix width
    self.img_height = img_height      # Matrix height
    self.mask_file = infile
    self.out_file = outfile
    self.prev_time = 0
    self.curr_time = 0

    self.num_captures = num_captures
    self.brightness = brightness_pct / 100
    self.sleep_time = sleep_time_ms / 1000

    self.min_time_delta = 1000
    self.max_time_delta = 0
    self.acc_time_delta = 0

    # Load the imaging mask
    self.mask_matrix = np.load(self.mask_file) * 255 * self.brightness
    # Measurement rows
    self.num_measurements = self.mask_matrix.shape[0]
    self.curr_capture = 0
    self.disp_width = DEFAULT_DISP_WIDTH      # Display width
    self.disp_height = DEFAULT_DISP_HEIGHT    # Display height
    self.init_props()


  def init_props(self):
    self.count = 0
    self.data_loc = 0
    self.started = False
    self.fullscreen = True
    self.sensor_readings = np.zeros((self.num_measurements, 1))
    self.time0 = 0                           # Will be used to time scan
    self.time_final = 0
    self.fp_flag = 0
    self.init_ui()

  def init_ui(self):
    # Choose a display before first capture
    if self.curr_capture == 0:
      num_screens = QtWidgets.QDesktopWidget().screenCount()
      print(f"\nDetected {num_screens} screens")
      if QtWidgets.QDesktopWidget().screenCount() == 1:
        print("Projector not detected. Please check the connection and try again.")
        if input("Continue? [y/n]").capitalize() != "Y":
          quit()

      print(f"Currently displaying on screen {QtWidgets.QDesktopWidget().screenNumber() + 1}")

      for s in range(num_screens):
        geometry = QtWidgets.QDesktopWidget().screenGeometry(s)
        print(f"{s + 1}) {geometry.width()} x {geometry.height()}")

      self.screen = input_int("Select the projector screen: ") - 1

      # Set window size and center
      self.resize(self.disp_width, self.disp_height)
      self.center()

      # Create a label (used to display the image)
      self.label = QtWidgets.QLabel(self)
      self.label.setAlignment(QtCore.Qt.AlignCenter)

      self.col = QtGui.QColor(0, 0, 0)
      self.label.setGeometry(QtCore.QRect(0, 0, self.disp_width, self.disp_height))

    # Flush serial, display the first frame
    self.ser.write(b'9')
    self.update_projector(0)
    time.sleep(1.0)

    # Set up the timer
    self.timer = QtCore.QTimer()
    self.showNormal()
    print("\nPeriod in msecs: ", 1000 / self.scan_rate)
    self.go()

  def update_projector(self, count):
    # Need to scale mask aspect ratio accordingly.
    # Measurement "row"
    mask_shaped = np.reshape(self.mask_matrix[count, :], (self.img_height, self.img_width))
    mask_shaped = np.require(mask_shaped, np.uint8, 'C')
    mask_qimage = QtGui.QImage(mask_shaped, mask_shaped.shape[1], mask_shaped.shape[0], QtGui.QImage.Format_Indexed8)

    # If you display a square, it doesn't actually show up as square... (narrower)
    scaled_height = self.disp_height * 0.95
    scaled_width = (4 / 3 * self.img_width / self.img_height) * scaled_height

    self.label.setPixmap(QtGui.QPixmap.fromImage(mask_qimage).scaled(int(scaled_width), int(scaled_height)))

  def center(self):
    qr = self.frameGeometry()
    cp = QtWidgets.QDesktopWidget().availableGeometry(self.screen).center()
    qr.moveCenter(cp)
    self.move(qr.topLeft())
    if QtWidgets.QDesktopWidget().screenCount() == 2 and self.screen == 1:       # They have chosen to display on projector
      self.move(QtWidgets.QDesktopWidget().screenGeometry(0).width() + 12, -12)

  def read_sensor_data(self):
    # Tell Arduino to collect data
    self.ser.write(b'6')

    serial_data = self.ser.readline()
    # Convert ASCII characters from serial port to integers
    serial_data_processed = []
    for i in serial_data:
      if chr(i) != '\r' and chr(i) != '\n':
        serial_data_processed.append(i)
    serial_data_length = len(serial_data_processed)

    data = 0
    count = 1

    for j in serial_data_processed:
      data += pow(10, serial_data_length - count) * int(chr(j))
      count += 1

    # When timeout is too low, sometimes nothing is received... we want a redo in that case (detect invalid)
    if serial_data_length == 0:
      data = -1
    return data

  def update_data(self):
    global SCAN_DELAY

    # Not sure why I need this... data doesn't seem to be properly aligned
    # Probably some interplay between timer interrupt + sleep?
    shift_correction = 2 if self.sleep_time > 0.09 else 3

    if self.count < self.num_measurements + shift_correction:
      if self.fp_flag < SCAN_DELAY / (1000 / self.scan_rate):
        self.fp_flag += 1
        # Need to match capture index with screen being displayed
        self.count = -1
      elif self.fp_flag == SCAN_DELAY / (1000 / self.scan_rate):
        self.time0 = time.time()
        self.fp_flag += 1

      # Update what's being displayed to projector
      cnt = (self.num_measurements - 1) if self.count == -1 else self.count

      # Don't update screen on last scan count (just read out value)
      if self.count < self.num_measurements:
        self.update_projector(cnt)

      # Sleep for some time to allow sensor output to settle
      time.sleep(self.sleep_time)

      # Looks like when UART isn't ready, it'll just show up as newline, which gets read and screws up timing
      # Alternatives: change timeout (increase, so scan takes longer) OR [what I do] just don't increment save location
      # when a blank line is returned (hopefully everything gets properly appended at the end)
      if self.count == -1:
        self.data_loc = -1 - shift_correction

      if self.count < shift_correction:
        data = self.read_sensor_data()
        if data > -1:
          self.data_loc += 1
      elif self.count >= shift_correction:
        data = self.read_sensor_data()
        self.prev_time = self.curr_time
        self.curr_time = time.time()
        time_delta = self.curr_time - self.prev_time
        self.acc_time_delta += time_delta

        if self.count > shift_correction:
          if time_delta < self.min_time_delta:
            self.min_time_delta = time_delta
          if time_delta > self.max_time_delta:
            self.max_time_delta = time_delta

        self.sensor_readings[self.data_loc] = data
        if self.data_loc % 100 == 0 or self.data_loc < 10 or self.data_loc > (self.num_measurements + shift_correction - 10) or data == -1:
          print(f"Pixel {self.data_loc}/{self.num_measurements} has value {data}")
        if data > -1:
          self.data_loc += 1
        elif data == -1:
          print("Losing data! Consider increasing your timeout!")

      # if timeout not long enough, redo!
      self.count += 1

    else:

      if self.data_loc < self.num_measurements - 1:
        print("Lost %s data! :( Please increase timeout!" % ((self.num_measurements - 1) - self.data_loc))

      self.timer.stop()
      self.time_final = time.time()
      print("\nScan completed")
      print("Scan time: %.3f s" % (self.time_final - self.time0))
      print(f"Min time delta in s: {self.min_time_delta}")
      print(f"Max time delta in s: {self.max_time_delta}")
      print(f"Average time delta in s: {self.acc_time_delta / self.num_measurements}")

      extra_data = []
      while self.ser.inWaiting():
        data = self.read_sensor_data()
        extra_data.append(data)

      print("Length of extra_data: ", len(extra_data))
      print("Extra Data: ", extra_data)

      self.sensor_readings = np.append(self.sensor_readings[:self.data_loc], np.reshape(extra_data, (len(extra_data), 1)), axis = 0)

      # If you're just taking linear measurements, don't need to restrict yourself to screen size
      # N = width
      reshapeHeight = int(np.ceil(len(self.sensor_readings) / self.img_width))
      reshapeSize = reshapeHeight * self.img_width

      # Awkwardly fill in to get a full row for displaying (why ceil is used)
      padAmount = reshapeSize - len(self.sensor_readings)

      # Should be column vector!
      paddedSensorReadings = np.append(self.sensor_readings, np.transpose([[np.amax(self.sensor_readings)] * padAmount]), axis = 0)

      if reshapeHeight != int(len(self.sensor_readings) / self.img_width):
        print(f"Incomplete measurement row. Is your mask matrix size correct? Padding outputs {padAmount} times for display.")

      saveFile = self.out_file + "_" + str(int(self.brightness * 100)) + "_" + str(self.curr_capture)
      print(f"Saving data as {saveFile}.npy")

      np.save(f"{saveFile}.npy", self.sensor_readings)
      self.curr_capture += 1

      plt.figure()
      img = np.reshape(paddedSensorReadings, (reshapeHeight, self.img_width))
      plt.imshow(img, cmap='gray')
      plt.title('Capture Image Results')
      plt.show()

      print(f"Min sensor reading: {np.amin(paddedSensorReadings)}")
      print(f"Max sensor reading: {np.amax(paddedSensorReadings)}")

      if self.curr_capture < self.num_captures:
        self.init_props()
      else:
        self.close()

  def rescale(self):
    if self.fullscreen:
      self.disp_width = DEFAULT_DISP_WIDTH   # Display width
      self.disp_height = DEFAULT_DISP_HEIGHT # Display height
    else:
      self.disp_width = QtGui.QDesktopWidget().screenGeometry(self.screen).width()
      self.disp_height = QtGui.QDesktopWidget().screenGeometry(self.screen).height()

    self.label.setGeometry(QtCore.QRect(0, 0, self.disp_width, self.disp_height))
    qi = QtGui.QImage(self.mask.data, self.img_width, self.img_height, QtGui.QImage.Format_Indexed8)
    self.label.setPixmap(QtGui.QPixmap.fromImage(qi).scaled(int(self.disp_width), int(self.disp_height), QtCore.Qt.KeepAspectRatio))

  def go(self):
    self.ser.flushOutput()
    self.ser.flushInput()
    time.sleep(1.0)
    print(f"\nStarting scan {self.curr_capture}... \n Total scans required: {self.num_measurements}")
    self.started = True
    self.timer.start(int(1000 / self.scan_rate))
    self.timer.timeout.connect(self.update_data)


class SignalWakeupHandler(QtNetwork.QAbstractSocket):
  signal_received = QtCore.pyqtSignal(int)

  def __init__(self, parent = None):
    super().__init__(QtNetwork.QAbstractSocket.UdpSocket, parent)
    self.wsock, self.rsock = socket.socketpair(type = socket.SOCK_STREAM)
    self.setSocketDescriptor(self.rsock.fileno())
    self.wsock.setblocking(False)
    signal.set_wakeup_fd(self.wsock.fileno())
    self.readyRead.connect(lambda: None)
    self.readyRead.connect(self._read_signal)

  def _read_signal(self):
    data = self.readData(1)
    self.signal_received.emit(data[0])


def main():
  print("\nEECS16A Imaging Lab\n")

  # Parse arguments
  parser = argparse.ArgumentParser(description = 'This program projects a sampling pattern and records the corresponding phototransistor voltage.')
  parser.add_argument('-f', '--fps', type = int, default = 40, help = 'frames per second (default = 40)')
  parser.add_argument('--width', type = int, default = 40, help = 'width of the image in pixels (default = 40px)')
  parser.add_argument('--height', type = int, default = 30, help = 'height of the image in pixels (default = 30px)')
  parser.add_argument('--mask', default = "masks/diag_mask.npy", help = 'saved sampling pattern mask (default = "masks/diag_mask.npy")')
  parser.add_argument('--out', default = "images/sensor_readings", help = 'output path (default="images/sensor_readings", saved as "images/sensor_readings_0.npy")')
  parser.add_argument('--numCaptures', type = int, default = 1, help = 'number of image captures (for averaging)')
  parser.add_argument('--sleepTime', type = int, default = 120, help = 'sleep time in milliseconds -- time between projector update and data capture')
  parser.add_argument('--brightness', type = int, default = 100, help = '% of full projector brightness to use')
  parser.add_argument('--timeout', type = int, default = 150, help = 'serial timeout in ms (default = 40)')

  args = parser.parse_args()

  print(f"Serial timeout in ms: {args.timeout}")
  print(f"Sleep time in ms: {args.sleepTime}")
  print(f"Projector brightness scale in percent: {args.brightness}")

  print(f"FPS: {args.fps}")
  print(f"Image width: {args.width}")
  print(f"Image height: {args.height}")

  print(f"Mask file: {args.mask}\n")

  print("Checking serial connections...")

  ports = [p.device for p in serial.tools.list_ports.comports()]
  if ports:
    print("Available serial ports:")
    for (i, p) in enumerate(ports):
      print(f"{i + 1}) {p}")
  else:
    print("No ports available. Check serial connection and try again.")
    print("Exiting...")
    quit()

  timeout = args.timeout / 1000

  selection = input("Select the port to use: ")

  # Note: seems like timeout of 1 doesn't work
  with serial.Serial(ports[int(selection) - 1], BAUD_RATE, timeout = timeout) as ser:
    app = QtWidgets.QApplication(sys.argv)
    mask = Mask(ser, args.fps, args.width, args.height, args.mask, args.out, args.numCaptures, args.brightness, args.sleepTime)
  
    SignalWakeupHandler(app)
    signal.signal(signal.SIGINT, lambda sig, _: app.quit())

    sys.exit(app.exec_())

if __name__ == '__main__':
  main()
