def breadboard_hint(displayed):
    if displayed:
        from IPython.display import Image, display
        display(Image(filename='img/task3c_phy.png', width=500))


def real_hint(displayed):
    if displayed:
        from IPython.display import HTML, display
        command = f'''
            <center>
                <img src="img/voltage_divider-zoom.jpg" align="center" style="height:400px; display:inline-block" />
                <img src="img/voltage_divider-copy.jpg" align="center" style="height:400px; display:inline-block" />
                <img src="img/voltage_divider-front.jpg" align="center" style="height:400px; display:inline-block" />
            </center>
        '''
        display(HTML(data=command))